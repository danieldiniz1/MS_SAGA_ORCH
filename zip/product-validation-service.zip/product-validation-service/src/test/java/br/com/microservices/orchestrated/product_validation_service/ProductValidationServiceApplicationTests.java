package br.com.microservices.orchestrated.product_validation_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductValidationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
